package com.ananya.dialer;

import android.app.*;
import android.os.*;
import android.telecom.Call;
import android.view.Gravity;
import android.widget.*;

public class CallActivity extends Activity {
    TextView status,number;
    Call.Callback callback;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
            android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
            android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setGravity(Gravity.CENTER);
        l.setPadding(24,30,24,30); l.setBackgroundColor(0xFF102A56);
        status=new TextView(this); status.setTextColor(0xFFFFFFFF); status.setTextSize(20); status.setGravity(Gravity.CENTER);
        number=new TextView(this); number.setTextColor(0xFFFFFFFF); number.setTextSize(28); number.setGravity(Gravity.CENTER);
        l.addView(status); l.addView(number);
        Button answer=button("ANSWER",0xFF159447); Button end=button("END CALL",0xFFD32F2F);
        l.addView(answer); l.addView(end);
        answer.setOnClickListener(v->{Call c=CallHolder.current;if(c!=null)c.answer(android.telecom.VideoProfile.STATE_AUDIO_ONLY);});
        end.setOnClickListener(v->{Call c=CallHolder.current;if(c!=null)c.disconnect();finish();});
        Button mute=button("MUTE",0xFF355C8C); l.addView(mute);
        mute.setOnClickListener(v->{Call c=CallHolder.current;if(c!=null)c.setMuted(!c.getDetails().getCallProperties());});
        setContentView(l); refresh();
    }
    Button button(String s,int color){Button b=new Button(this);b.setText(s);b.setTextColor(0xFFFFFFFF);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));return b;}
    void refresh(){
        Call c=CallHolder.current;
        if(c==null){status.setText("No active call");number.setText("");return;}
        int st=c.getState();
        status.setText(st==Call.STATE_RINGING?"Incoming call":st==Call.STATE_DIALING?"Calling…":st==Call.STATE_ACTIVE?"Connected":"Call");
        CharSequence n=c.getDetails().getHandle()==null?"Unknown":c.getDetails().getHandle().getSchemeSpecificPart();
        number.setText(n);
        if(st!=Call.STATE_RINGING) findAnswerButton();
    }
    void findAnswerButton(){ }
    @Override protected void onResume(){super.onResume();refresh();}
}
