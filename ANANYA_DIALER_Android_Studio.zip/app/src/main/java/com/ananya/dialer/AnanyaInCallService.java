package com.ananya.dialer;

import android.telecom.Call;
import android.telecom.InCallService;
import android.content.Intent;

public class AnanyaInCallService extends InCallService {
    @Override public void onCallAdded(Call call) {
        super.onCallAdded(call);
        CallHolder.current=call;
        Intent i=new Intent(this,CallActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
    }
    @Override public void onCallRemoved(Call call) {
        if(CallHolder.current==call) CallHolder.current=null;
        super.onCallRemoved(call);
    }
}
