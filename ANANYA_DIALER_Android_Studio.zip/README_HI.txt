ANANYA DIALER - Android Studio Project

इस ZIP में Android Studio का शुरुआती native Android project है।
इसे खोलने के लिए:
1. Android Studio में File > Open चुनें और इस ZIP को extract करके ANANYA_DIALER_Android_Studio folder खोलें।
2. Gradle sync पूरा होने दें।
3. फोन में Developer options और USB debugging चालू करके Run करें, या Build > Build APK(s) चुनें।
4. फोन पर ऐप खोलकर इसे Default Phone/Dialer app बनाने की अनुमति दें।

महत्वपूर्ण:
- यह पहला कार्यशील starter build है, पूर्ण व्यावसायिक रूप से परीक्षण किया गया dialer नहीं।
- Default dialer भूमिका और InCallService का व्यवहार Android version तथा फोन निर्माता के अनुसार बदल सकता है।
- Contacts, call log और call permission केवल आवश्यक अनुमति देने पर उपलब्ध होंगे।
- फोन कॉल के लिए SIM/network आवश्यक है।
- इस संस्करण में call recording, call blocking, dual-SIM चयन, favorites management और विस्तृत call controls शामिल नहीं हैं।
- फोन पर install करने से पहले Android Studio में build करके वास्तविक डिवाइस पर incoming/outgoing call परीक्षण करें।
