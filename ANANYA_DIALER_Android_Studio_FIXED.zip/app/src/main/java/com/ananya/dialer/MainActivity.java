package com.ananya.dialer;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.telecom.TelecomManager;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.database.Cursor;
import android.provider.CallLog;
import android.provider.ContactsContract;

public class MainActivity extends Activity {
    EditText number;
    LinearLayout root;
    static final int REQ_PERMS=21;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF102A56);
        getWindow().setNavigationBarColor(0xFF102A56);
        buildUI();
        requestNeededPermissions();
        requestDialerRole();
    }
    void requestNeededPermissions() {
        String[] p={"android.permission.CALL_PHONE","android.permission.READ_CONTACTS","android.permission.READ_CALL_LOG","android.permission.ANSWER_PHONE_CALLS"};
        if (Build.VERSION.SDK_INT>=23) {
            java.util.ArrayList<String> ask=new java.util.ArrayList<>();
            for(String x:p) if(checkSelfPermission(x)!=PackageManager.PERMISSION_GRANTED) ask.add(x);
            if(!ask.isEmpty()) requestPermissions(ask.toArray(new String[0]),REQ_PERMS);
        }
    }
    void requestDialerRole() {
        if(Build.VERSION.SDK_INT>=29) {
            android.app.role.RoleManager rm=getSystemService(android.app.role.RoleManager.class);
            if(rm!=null && rm.isRoleAvailable(android.app.role.RoleManager.ROLE_DIALER) &&
                !rm.isRoleHeld(android.app.role.RoleManager.ROLE_DIALER))
                startActivityForResult(rm.createRequestRoleIntent(android.app.role.RoleManager.ROLE_DIALER),44);
        } else {
            Intent i=new Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER);
            i.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME,getPackageName());
            startActivityForResult(i,44);
        }
    }
    TextView text(String s,int size,int color) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); return t;
    }
    void buildUI() {
        root=new LinearLayout(this); root.setOrientation(1); root.setPadding(18,12,18,12); root.setBackgroundColor(0xFFF4F6FA);
        TextView brand=text("ANANYA DIALER",22,0xFFFFFFFF); brand.setTypeface(null,1);
        brand.setBackgroundColor(0xFF102A56); brand.setPadding(8,18,8,18); root.addView(brand);
        TextView sub=text("Smart • Simple • Personal",13,0xFF52627A); root.addView(sub);
        number=new EditText(this); number.setSingleLine(true); number.setTextSize(26); number.setGravity(Gravity.CENTER);
        number.setHint("Enter phone number"); number.setInputType(3); root.addView(number,new LinearLayout.LayoutParams(-1,68));
        String[][] keys={{"1","2","3"},{"4","5","6"},{"7","8","9"},{"*","0","#"}};
        for(String[] row:keys) {
            LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER);
            for(String k:row) {
                Button btn=new Button(this); btn.setText(k); btn.setTextSize(21);
                r.addView(btn,new LinearLayout.LayoutParams(0,62,1));
                btn.setOnClickListener(v->number.append(k));
            }
            root.addView(r);
        }
        LinearLayout actions=new LinearLayout(this);
        Button del=new Button(this); del.setText("⌫"); actions.addView(del,new LinearLayout.LayoutParams(0,60,1));
        del.setOnClickListener(v->{int n=number.length(); if(n>0) number.getText().delete(n-1,n);});
        Button call=new Button(this); call.setText("📞  CALL"); call.setTextColor(0xFFFFFFFF); call.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF159447));
        actions.addView(call,new LinearLayout.LayoutParams(0,60,2));
        call.setOnClickListener(v->makeCall());
        root.addView(actions);
        LinearLayout tabs=new LinearLayout(this);
        addTab(tabs,"Recent",()->showCallLog());
        addTab(tabs,"Contacts",()->showContacts());
        addTab(tabs,"Set Default",()->requestDialerRole());
        root.addView(tabs);
        TextView info=text("Set ANANYA DIALER as your default phone app to handle incoming and outgoing calls.",12,0xFF667085);
        info.setPadding(8,14,8,4); root.addView(info);
        setContentView(root);
    }
    void addTab(LinearLayout row,String label,Runnable action) {
        Button b=new Button(this); b.setText(label); row.addView(b,new LinearLayout.LayoutParams(0,54,1)); b.setOnClickListener(v->action.run());
    }
    void makeCall() {
        String n=number.getText().toString().trim();
        if(n.isEmpty()){number.setError("Enter a phone number");return;}
        try {
            Intent i=new Intent(Intent.ACTION_CALL,Uri.fromParts("tel",n,null));
            startActivity(i);
        } catch(Exception e) { Toast.makeText(this,"Call permission or SIM service is unavailable",Toast.LENGTH_LONG).show(); }
    }
    void showCallLog() {
        if(checkSelfPermission("android.permission.READ_CALL_LOG")!=PackageManager.PERMISSION_GRANTED){requestNeededPermissions();return;}
        StringBuilder s=new StringBuilder("Recent calls\n\n");
        try(Cursor c=getContentResolver().query(CallLog.Calls.CONTENT_URI,null,null,null,CallLog.Calls.DATE+" DESC")) {
            int count=0;
            if(c!=null) while(c.moveToNext() && count++<40) {
                String n=c.getString(c.getColumnIndexOrThrow(CallLog.Calls.NUMBER));
                int type=c.getInt(c.getColumnIndexOrThrow(CallLog.Calls.TYPE));
                String label=type==CallLog.Calls.INCOMING_TYPE?"Incoming":type==CallLog.Calls.OUTGOING_TYPE?"Outgoing":type==CallLog.Calls.MISSED_TYPE?"Missed":"Call";
                s.append(label).append("  ").append(n).append("\n");
            }
        } catch(Exception e){s.append("Call history could not be read.");}
        showList("Call History",s.toString());
    }
    void showContacts() {
        if(checkSelfPermission("android.permission.READ_CONTACTS")!=PackageManager.PERMISSION_GRANTED){requestNeededPermissions();return;}
        StringBuilder s=new StringBuilder("Contacts\n\n");
        try(Cursor c=getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},
                null,null,ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME+" ASC")) {
            int count=0;
            if(c!=null) while(c.moveToNext() && count++<100) s.append(c.getString(0)).append("  ").append(c.getString(1)).append("\n");
        } catch(Exception e){s.append("Contacts could not be read.");}
        showList("Contacts",s.toString());
    }
    void showList(String title,String content) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(content).setPositiveButton("Close",null).show();
    }
}
