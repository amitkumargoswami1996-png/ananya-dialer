package com.ananya.dialer;
import android.telecom.Call;
public class CallHolder { public static Call current; }
