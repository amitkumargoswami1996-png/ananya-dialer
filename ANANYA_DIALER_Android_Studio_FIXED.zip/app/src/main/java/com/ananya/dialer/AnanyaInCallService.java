package com.ananya.dialer;

import android.telecom.Call;
import android.telecom.InCallService;
import android.content.Intent;

public class AnanyaInCallService extends InCallService {
    public static AnanyaInCallService instance;

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
    }

    public static boolean isMutedNow() {
        return instance != null && instance.getCallAudioState() != null
                && instance.getCallAudioState().isMuted();
    }

    public static void changeMute(boolean muted) {
        if (instance != null) instance.setMuted(muted);
    }

    @Override public void onCallAdded(Call call) {
        super.onCallAdded(call);
        CallHolder.current = call;
        Intent i = new Intent(this, CallActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
    }

    @Override public void onCallRemoved(Call call) {
        if (CallHolder.current == call) CallHolder.current = null;
        super.onCallRemoved(call);
    }

    @Override public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }
}
