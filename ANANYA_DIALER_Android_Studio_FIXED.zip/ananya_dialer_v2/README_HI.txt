ANANYA DIALER — Android project v1.1

यह मोबाइल से GitHub Actions द्वारा APK बनाने के लिए Android Studio project है।

इस अपडेट में:
- Native dial pad और outgoing call intent
- Android contacts list (permission मिलने पर), contact चुनकर call / dial pad में भरना
- Recent call log (permission मिलने पर)
- Favorites: Contacts/Recent entry से Add/Remove Favorite; local device पर सुरक्षित
- Default Phone/Dialer role request अब अलग button से शुरू होती है, app launch पर जबरन नहीं
- InCallService आधारित incoming/active call screen
- Answer, End, Mute, Speaker, Hold/Resume और उपलब्ध होने पर Merge request
- Android target SDK 35, Java 17 / AGP 8.7.3 compatible project layout

महत्वपूर्ण सीमाएँ:
- Default Dialer बनने की स्वीकृति Android OS/OEM के eligibility checks पर निर्भर है। इस ऐप में system security restriction को bypass नहीं किया जाता।
- Merge केवल तभी काम करेगा जब Telecom API दूसरी call को conferenceable बताए और carrier/SIM conference calling सपोर्ट करे।
- Dual-SIM selection, number blocking और call recording इस build में implement नहीं हैं। Call recording Android version, manufacturer, carrier, consent और स्थानीय कानून से सीमित होती है।
- यह source update है; इस environment में Android SDK/Gradle build चलाकर APK compile test नहीं किया गया। GitHub Actions build result को जाँचना जरूरी है।

GitHub Actions workflow ZIP में settings.gradle खोजकर project root पहचानता है। इस ZIP को repository root में upload करें और workflow run पूरा होने पर artifact डाउनलोड करें।


V1.2 UI FIX:
- Explicit keypad button text/background colors added for OEM theme compatibility.
- Explicit dial input text and hint colors added.
- Explicit tab button colors and typography added.
- App version updated to 1.2.
\n\nV1.3 TEXTVIEW UI FIX:\n- Replaced keypad, call, delete and tab Button widgets with styled TextViews.\n- Added explicit rounded backgrounds, text colors, gravity and margins to avoid manufacturer Button theme rendering issues.\n- Added explicit number-entry background.\n- Version updated to 1.3.\n