package com.ananya.dialer;
import android.telecom.Call;
public final class CallHolder { public static volatile Call current; private CallHolder() {} }
