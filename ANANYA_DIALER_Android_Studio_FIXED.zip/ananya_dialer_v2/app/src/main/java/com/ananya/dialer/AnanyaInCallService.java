package com.ananya.dialer;

import android.content.Intent;
import android.telecom.Call;
import android.telecom.InCallService;
import java.util.ArrayList;
import java.util.List;

public class AnanyaInCallService extends InCallService {
    public static AnanyaInCallService instance;
    private static final List<Call> calls = new ArrayList<>();

    @Override public void onCreate() { super.onCreate(); instance = this; }

    @Override public void onCallAdded(Call call) {
        super.onCallAdded(call);
        synchronized (calls) { if (!calls.contains(call)) calls.add(call); }
        CallHolder.current = call;
        Intent i = new Intent(this, CallActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
    }

    @Override public void onCallRemoved(Call call) {
        synchronized (calls) { calls.remove(call); }
        if (CallHolder.current == call) {
            synchronized (calls) { CallHolder.current = calls.isEmpty() ? null : calls.get(calls.size() - 1); }
        }
        super.onCallRemoved(call);
    }

    public static boolean isMutedNow() {
        return instance != null && instance.getCallAudioState() != null && instance.getCallAudioState().isMuted();
    }
    public static void changeMute(boolean muted) { if (instance != null) instance.setMuted(muted); }
    public static boolean isSpeakerOn() {
        return instance != null && instance.getCallAudioState() != null &&
                instance.getCallAudioState().getRoute() == android.telecom.CallAudioState.ROUTE_SPEAKER;
    }
    public static void toggleSpeaker() {
        if (instance == null || instance.getCallAudioState() == null) return;
        int route = isSpeakerOn() ? android.telecom.CallAudioState.ROUTE_EARPIECE : android.telecom.CallAudioState.ROUTE_SPEAKER;
        instance.setAudioRoute(route);
    }
    public static void mergeIfPossible() {
        Call current = CallHolder.current;
        if (current == null) return;
        List<Call> others = current.getConferenceableCalls();
        if (others != null && !others.isEmpty()) current.conference(others.get(0));
    }

    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }
}
