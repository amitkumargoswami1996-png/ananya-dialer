package com.ananya.dialer;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.telecom.TelecomManager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQ_PERMS = 21;
    private static final int REQ_DIALER_ROLE = 44;
    private EditText number;
    private LinearLayout root;
    private SharedPreferences prefs;
    private final int navy = 0xFF102A56;
    private final int green = 0xFF159447;
    private final int ink = 0xFF17243A;
    private final int muted = 0xFF667085;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("ananya_dialer", MODE_PRIVATE);
        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(navy);
        if (getIntent() != null && getIntent().getData() != null) {
            String incoming = getIntent().getData().getSchemeSpecificPart();
            if (incoming != null) pendingNumber = incoming;
        }
        buildUI();
        requestNeededPermissions();
    }

    private String pendingNumber = "";

    private void requestNeededPermissions() {
        if (Build.VERSION.SDK_INT < 23) return;
        String[] requested = {"android.permission.CALL_PHONE", "android.permission.READ_CONTACTS", "android.permission.READ_CALL_LOG"};
        ArrayList<String> missing = new ArrayList<>();
        for (String p : requested) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        if (!missing.isEmpty()) requestPermissions(missing.toArray(new String[0]), REQ_PERMS);
    }

    private TextView label(String value, int size, int color) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); return t;
    }

    private Button makeButton(String value, int color) {
        Button b = new Button(this); b.setText(value); b.setTextColor(0xFFFFFFFF);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        return b;
    }

    private void buildUI() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(16, 12, 16, 18); root.setBackgroundColor(0xFFF4F6FA);
        TextView brand = label("ANANYA DIALER", 24, 0xFFFFFFFF); brand.setGravity(Gravity.CENTER); brand.setTypeface(null, 1); brand.setPadding(12, 20, 12, 20); brand.setBackgroundColor(navy); root.addView(brand);
        TextView sub = label("Smart  •  Simple  •  Personal", 14, muted); sub.setGravity(Gravity.CENTER); sub.setPadding(4, 8, 4, 14); root.addView(sub);

        number = new EditText(this);
        number.setSingleLine(true);
        number.setTextSize(27);
        number.setGravity(Gravity.CENTER);
        number.setHint("Enter phone number");
        number.setHintTextColor(0xFF667085);
        number.setTextColor(ink);
        number.setInputType(3);
        number.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFCBD5E1));
        root.addView(number, new LinearLayout.LayoutParams(-1, 64));
        if (!pendingNumber.isEmpty()) number.setText(pendingNumber);

        String[][] keys = {{"1", "2", "3"}, {"4", "5", "6"}, {"7", "8", "9"}, {"*", "0", "#"}};
        for (String[] row : keys) {
            LinearLayout line = new LinearLayout(this); line.setGravity(Gravity.CENTER);
            for (String key : row) {
                Button b = new Button(this);
                b.setText(key);
                b.setTextSize(21);
                b.setTextColor(ink);
                b.setAllCaps(false);
                b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFFFFFFF));
                line.addView(b, new LinearLayout.LayoutParams(0, 58, 1));
                b.setOnClickListener(v -> number.append(key));
            }
            root.addView(line);
        }
        LinearLayout actions = new LinearLayout(this);
        Button erase = makeButton("⌫", 0xFF667085); actions.addView(erase, new LinearLayout.LayoutParams(0, 58, 1));
        erase.setOnClickListener(v -> { int n = number.length(); if (n > 0) number.getText().delete(n - 1, n); });
        Button call = makeButton("☎  CALL", green); actions.addView(call, new LinearLayout.LayoutParams(0, 58, 2)); call.setOnClickListener(v -> makeCall());
        root.addView(actions);

        LinearLayout tabs1 = new LinearLayout(this);
        addTab(tabs1, "Recent Calls", this::showCallLog);
        addTab(tabs1, "Contacts", this::showContacts);
        root.addView(tabs1);
        LinearLayout tabs2 = new LinearLayout(this);
        addTab(tabs2, "★ Favorites", this::showFavorites);
        addTab(tabs2, "Set Default Dialer", this::requestDialerRole);
        root.addView(tabs2);
        TextView note = label("Default Phone role is optional until you choose it. Android may show a system security or eligibility prompt.", 12, muted);
        note.setGravity(Gravity.CENTER); note.setPadding(8, 12, 8, 4); root.addView(note);
        scroll.addView(root); setContentView(scroll);
    }

    private void addTab(LinearLayout row, String title, Runnable action) {
        Button b = new Button(this);
        b.setText(title);
        b.setTextColor(navy);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFE6ECF5));
        row.addView(b, new LinearLayout.LayoutParams(0, 54, 1));
        b.setOnClickListener(v -> action.run());
    }

    private void makeCall() {
        String value = number.getText().toString().trim();
        if (value.isEmpty()) { number.setError("Enter a phone number"); return; }
        if (checkSelfPermission("android.permission.CALL_PHONE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.CALL_PHONE"}, REQ_PERMS); return;
        }
        try { startActivity(new Intent(Intent.ACTION_CALL, Uri.fromParts("tel", value, null))); }
        catch (Exception e) { Toast.makeText(this, "Call could not start. Check SIM, network and permission.", Toast.LENGTH_LONG).show(); }
    }

    private void requestDialerRole() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                RoleManager rm = getSystemService(RoleManager.class);
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                    if (rm.isRoleHeld(RoleManager.ROLE_DIALER)) Toast.makeText(this, "ANANYA DIALER is already the default phone app", Toast.LENGTH_LONG).show();
                    else startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), REQ_DIALER_ROLE);
                } else Toast.makeText(this, "Default dialer role is not available on this device", Toast.LENGTH_LONG).show();
            } else {
                Intent i = new Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER);
                i.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, getPackageName());
                startActivityForResult(i, REQ_DIALER_ROLE);
            }
        } catch (Exception e) { Toast.makeText(this, "Android did not allow the default dialer request: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    private void showCallLog() {
        if (checkSelfPermission("android.permission.READ_CALL_LOG") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.READ_CALL_LOG"}, REQ_PERMS); return;
        }
        ArrayList<String> lines = new ArrayList<>(); ArrayList<String> nums = new ArrayList<>();
        try (Cursor c = getContentResolver().query(CallLog.Calls.CONTENT_URI,
                new String[]{CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE}, null, null, CallLog.Calls.DATE + " DESC")) {
            if (c != null) while (c.moveToNext() && lines.size() < 50) {
                String n = c.getString(0); int type = c.getInt(1);
                String kind = type == CallLog.Calls.INCOMING_TYPE ? "Incoming" : type == CallLog.Calls.OUTGOING_TYPE ? "Outgoing" : type == CallLog.Calls.MISSED_TYPE ? "Missed" : "Call";
                lines.add(kind + "  •  " + n); nums.add(n == null ? "" : n);
            }
        } catch (Exception e) { Toast.makeText(this, "Call history unavailable: " + e.getMessage(), Toast.LENGTH_LONG).show(); return; }
        showSelectableList("Recent Calls", lines, nums, false);
    }

    private void showContacts() {
        if (checkSelfPermission("android.permission.READ_CONTACTS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.READ_CONTACTS"}, REQ_PERMS); return;
        }
        ArrayList<String> lines = new ArrayList<>(); ArrayList<String> nums = new ArrayList<>();
        try (Cursor c = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER},
                null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")) {
            if (c != null) while (c.moveToNext() && lines.size() < 300) {
                String name = c.getString(0), phone = c.getString(1);
                lines.add((name == null ? "Unknown" : name) + "\n" + (phone == null ? "" : phone)); nums.add(phone == null ? "" : phone);
            }
        } catch (Exception e) { Toast.makeText(this, "Contacts unavailable: " + e.getMessage(), Toast.LENGTH_LONG).show(); return; }
        showSelectableList("Contacts", lines, nums, true);
    }

    private Set<String> favorites() { return new HashSet<>(prefs.getStringSet("favorites", new HashSet<>())); }

    private void showFavorites() {
        Set<String> fav = favorites(); ArrayList<String> lines = new ArrayList<>(); ArrayList<String> nums = new ArrayList<>();
        for (String n : fav) { lines.add("★  " + n); nums.add(n); }
        if (lines.isEmpty()) { new AlertDialog.Builder(this).setTitle("Favorites").setMessage("No favorites yet. Open Contacts or enter a number, then use Add to Favorites.").setPositiveButton("OK", null).show(); return; }
        showSelectableList("Favorites", lines, nums, true);
    }

    private void showSelectableList(String title, ArrayList<String> labels, ArrayList<String> nums, boolean allowFavorite) {
        if (labels.isEmpty()) { new AlertDialog.Builder(this).setTitle(title).setMessage("No entries found.").setPositiveButton("Close", null).show(); return; }
        String[] items = labels.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle(title).setItems(items, (dialog, which) -> {
            String n = nums.get(which); if (n.isEmpty()) return;
            String[] options = allowFavorite ? new String[]{"Call", "Use in dial pad", "Add / Remove Favorite"} : new String[]{"Call", "Use in dial pad"};
            new AlertDialog.Builder(this).setTitle(items[which]).setItems(options, (d, action) -> {
                if (action == 0) { number.setText(n); makeCall(); }
                else if (action == 1) { number.setText(n); }
                else {
                    Set<String> fav = favorites(); if (fav.contains(n)) fav.remove(n); else fav.add(n);
                    prefs.edit().putStringSet("favorites", fav).apply(); Toast.makeText(this, fav.contains(n) ? "Added to Favorites" : "Removed from Favorites", Toast.LENGTH_SHORT).show();
                }
            }).show();
        }).setPositiveButton("Close", null).show();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_PERMS) {
            boolean callGranted = checkSelfPermission("android.permission.CALL_PHONE") == PackageManager.PERMISSION_GRANTED;
            if (!callGranted) Toast.makeText(this, "Call permission was not granted; calling is unavailable.", Toast.LENGTH_LONG).show();
        }
    }
}
