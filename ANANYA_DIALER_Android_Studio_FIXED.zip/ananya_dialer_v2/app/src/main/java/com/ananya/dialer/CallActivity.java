package com.ananya.dialer;

import android.app.Activity;
import android.os.Bundle;
import android.telecom.Call;
import android.telecom.VideoProfile;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class CallActivity extends Activity {
    private TextView status, number;
    private Button answer, mute, speaker, hold, merge;
    private final Call.Callback callback = new Call.Callback() {
        @Override public void onStateChanged(Call call, int state) { runOnUiThread(CallActivity.this::refresh); }
        @Override public void onDetailsChanged(Call call, Call.Details details) { runOnUiThread(CallActivity.this::refresh); }
        @Override public void onConferenceableCallsChanged(Call call, java.util.List<Call> conferenceableCalls) { runOnUiThread(CallActivity.this::refresh); }
    };
    private Call registered;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        LinearLayout layout = new LinearLayout(this); layout.setOrientation(LinearLayout.VERTICAL); layout.setGravity(Gravity.CENTER); layout.setPadding(24, 30, 24, 30); layout.setBackgroundColor(0xFF102A56);
        status = text("Call", 20); number = text("", 28); layout.addView(status); layout.addView(number);
        answer = button("ANSWER", 0xFF159447); Button end = button("END CALL", 0xFFD32F2F);
        mute = button("MUTE", 0xFF355C8C); speaker = button("SPEAKER", 0xFF355C8C);
        hold = button("HOLD", 0xFF355C8C); merge = button("MERGE CALL", 0xFF355C8C);
        layout.addView(answer); layout.addView(end); layout.addView(mute); layout.addView(speaker); layout.addView(hold); layout.addView(merge);
        answer.setOnClickListener(v -> { Call c = CallHolder.current; if (c != null && c.getState() == Call.STATE_RINGING) c.answer(VideoProfile.STATE_AUDIO_ONLY); });
        end.setOnClickListener(v -> { Call c = CallHolder.current; if (c != null) c.disconnect(); finish(); });
        mute.setOnClickListener(v -> { AnanyaInCallService.changeMute(!AnanyaInCallService.isMutedNow()); updateControls(); });
        speaker.setOnClickListener(v -> { AnanyaInCallService.toggleSpeaker(); updateControls(); });
        hold.setOnClickListener(v -> {
            Call c = CallHolder.current; if (c == null) return;
            if (c.getState() == Call.STATE_ACTIVE) c.hold(); else if (c.getState() == Call.STATE_HOLDING) c.unhold();
            refresh();
        });
        merge.setOnClickListener(v -> {
            Call c = CallHolder.current;
            if (c != null && c.getConferenceableCalls() != null && !c.getConferenceableCalls().isEmpty()) {
                AnanyaInCallService.mergeIfPossible(); Toast.makeText(this, "Merge request sent", Toast.LENGTH_SHORT).show();
            } else Toast.makeText(this, "No conferenceable second call. Start or answer another call first; carrier support is required.", Toast.LENGTH_LONG).show();
        });
        setContentView(layout); refresh();
    }

    private TextView text(String s, int size) { TextView t = new TextView(this); t.setText(s); t.setTextColor(0xFFFFFFFF); t.setTextSize(size); t.setGravity(Gravity.CENTER); t.setPadding(8, 14, 8, 14); return t; }
    private Button button(String s, int color) { Button b = new Button(this); b.setText(s); b.setTextColor(0xFFFFFFFF); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color)); return b; }

    private void updateControls() {
        mute.setText(AnanyaInCallService.isMutedNow() ? "UNMUTE" : "MUTE");
        speaker.setText(AnanyaInCallService.isSpeakerOn() ? "SPEAKER ON" : "SPEAKER");
        Call c = CallHolder.current;
        hold.setText(c != null && c.getState() == Call.STATE_HOLDING ? "RESUME" : "HOLD");
        merge.setEnabled(c != null && c.getConferenceableCalls() != null && !c.getConferenceableCalls().isEmpty());
    }

    private void refresh() {
        Call c = CallHolder.current;
        if (registered != c) {
            if (registered != null) registered.unregisterCallback(callback);
            registered = c;
            if (registered != null) registered.registerCallback(callback);
        }
        if (c == null) { status.setText("No active call"); number.setText(""); answer.setVisibility(View.GONE); }
        else {
            int state = c.getState();
            status.setText(state == Call.STATE_RINGING ? "Incoming call" : state == Call.STATE_DIALING ? "Calling…" : state == Call.STATE_ACTIVE ? "Connected" : state == Call.STATE_HOLDING ? "On hold" : "Call");
            CharSequence n = c.getDetails().getHandle() == null ? "Unknown" : c.getDetails().getHandle().getSchemeSpecificPart();
            number.setText(n); answer.setVisibility(state == Call.STATE_RINGING ? View.VISIBLE : View.GONE);
        }
        updateControls();
    }

    @Override protected void onResume() { super.onResume(); refresh(); }
    @Override protected void onDestroy() { if (registered != null) registered.unregisterCallback(callback); super.onDestroy(); }
}
